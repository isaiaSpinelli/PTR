
#define STACK_SIZE         4096        /**< Taille de la pile par défaut */
#define MS                 1000000     /**< 1 ms exprimé en ns */

