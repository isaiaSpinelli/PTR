
int start_watchdog(void(* suspend_func)(void));


int end_watchdog(void);

