#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

#include <cobalt/stdio.h>

#include <alchemy/task.h>
#include <alchemy/timer.h>
#include <alchemy/sem.h>

#include "audio_player_board.h"
#include "audio_utils.h"

#define AUDIO_OUTPUT_TASK_NAME  "Audio output task"
#define SOURCE_TASK_NAME        "Source task"
#define SDCARD_WRITER_TASK_NAME "Sdcard writer task"
#define TIME_DISPLAY_TASK_NAME  "Time display task"
#define CONTROL_TASK_NAME       "Control task"
#define PROCESSING_TASK_NAME    "Processing task"

static RT_TASK audio_output_rt_task;
static RT_TASK source_rt_task;
static RT_TASK sdcard_writer_rt_task;
static RT_TASK time_display_rt_task;
static RT_TASK control_rt_task;
static RT_TASK processing_rt_task;

static RT_SEM task_barrier;

void audio_output_task(void *cookie)
{
    rt_sem_p(&task_barrier, TM_INFINITE);
    rt_printf("[%s] stopping\n", __FUNCTION__);
}

void source_task(void *cookie)
{
    rt_sem_p(&task_barrier, TM_INFINITE);
    rt_printf("[%s] stopping\n", __FUNCTION__);
}

void sdcard_writer_task(void *cookie)
{

    rt_sem_p(&task_barrier, TM_INFINITE);

    /* === Exemple d'écriture d'un fichier wav ===
     * NOTE : n'hésitez pas à adapter ce code en fonction de vos choix et besoins
     * 
    int audio_fd;
    void *audio_buf;
    ssize_t audio_buf_size;
    struct wav_header wh;
    int ret;
    
    wh.file_blkID   = WAV_FILE_BLKID;
    wh.fmt_blkID    = WAV_FMT_BLKID;
    wh.data_blkID   = WAV_DATA_BLKID;
    wh.data_size    = 0;

    write_wav_header(audio_fd, &wh);

    audio_fd = ...
    audio_buf = ...
    audio_buf_size = ...

    ret = append_wav_data(audio_fd, audio_buf, audio_buf_size);
    if (ret) {
        rt_printf("[%s] Couldn't append data\n", __FUNCTION__);
        ...
    }

    === Fin de l'exemple === */

    rt_printf("[%s] stopping\n", __FUNCTION__);
}

void processing_task(void *cookie)
{
    rt_sem_p(&task_barrier, TM_INFINITE);
    rt_printf("[%s] stopping\n", __FUNCTION__);
}

void time_display_task(void *cookie)
{
    rt_sem_p(&task_barrier, TM_INFINITE);
    rt_printf("[%s] stopping\n", __FUNCTION__);
}

void control_task(void *cookie)
{
    rt_sem_p(&task_barrier, TM_INFINITE);
    rt_printf("[%s] stopping\n", __FUNCTION__);
}

int 
main(int argc, char *argv[]) 
{
    int audio_fd;

    if (init_board() != 0) {
        perror("Error at board initialization.");
        exit(EXIT_FAILURE);
    }

    if (argc != 2) {
        printf("Not enough arguments!\n");
        exit(EXIT_FAILURE);
    }

    /* Ouverture du fichier audio */
    audio_fd = open(argv[1], O_RDWR|O_CREAT);
    if (audio_fd < 0) {
        perror("Opening audio file");
        exit(EXIT_FAILURE);
    }

    /* Setup task barrier */
    if (rt_sem_create(&task_barrier, "Task barrier", 0, S_FIFO)) {
        perror("Creating task barrier");
        exit(EXIT_FAILURE);
    }

    mlockall(MCL_CURRENT | MCL_FUTURE);

    rt_task_spawn(&source_rt_task, SOURCE_TASK_NAME, 0, 99, T_JOINABLE, source_task, NULL);
    rt_task_spawn(&time_display_rt_task, TIME_DISPLAY_TASK_NAME, 0, 99, T_JOINABLE, time_display_task, NULL);
    rt_task_spawn(&control_rt_task, CONTROL_TASK_NAME, 0, 99, T_JOINABLE, control_task, NULL);
    rt_task_spawn(&audio_output_rt_task, AUDIO_OUTPUT_TASK_NAME, 0, 99, T_JOINABLE, audio_output_task, NULL);
    rt_task_spawn(&processing_rt_task, PROCESSING_TASK_NAME, 0, 99, T_JOINABLE, processing_task, NULL);
    rt_task_spawn(&sdcard_writer_rt_task, SDCARD_WRITER_TASK_NAME, 0, 99, T_JOINABLE, sdcard_writer_task, NULL);

    rt_sem_broadcast(&task_barrier);

    rt_task_join(&time_display_rt_task);
    rt_task_join(&control_rt_task);
    rt_task_join(&source_rt_task);
    rt_task_join(&audio_output_rt_task);
    rt_task_join(&processing_rt_task);
    rt_task_join(&sdcard_writer_rt_task);

    clean_board();
    close(audio_fd);

    munlockall();

    return EXIT_SUCCESS;
}